import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ErrorState } from '../components/ErrorState'
import { Icon } from '../components/Icon'
import { Loading } from '../components/Loading'
import { TopBar } from '../components/Layout'
import { classNames, fmtInt, fmtMoney, toast } from '../lib/ui'
import {
  COMMITTED_STATUSES,
  buildBookMarkdown,
  buildBookTxt,
  buildTruthMarkdown,
  downloadTextFile,
  nowStamp,
  safeFilename,
  type ChapterRow,
  type ExportChapter,
  type TruthBundle,
} from '../lib/export'
import { useProject } from '../state/project'
import {
  createProject,
  getChapter,
  getOverview,
  getStructure,
  getStyle,
  getWorld,
  health,
  listChapters,
  listCharacters,
  listHooks,
  listProjects,
  request,
} from '../api/client'

/**
 * 我的作品（首页）—— 项目总览 / 继续创作 / 新建 / 拆书入口。
 * 数据来自 `GET /api/projects`（列表）与 `GET /api/projects/{id}/overview`（继续创作的恢复建议）。
 */

interface ProjectSummary {
  id: string
  title: string
  genre: string
  logline: string
  mode: string
  chaptersDone: number
  chaptersTotal: number
  words: number
  budgetUsed: number
  budgetTotal: number
  updatedAt: string
  hooksResolved: number
  hooksTotal: number
  auditPass: number
  isCurrent?: boolean
}

interface Resume {
  action: string
  label: string
  chapter: number
  stepLabel: string
  reason: string
}

interface HealthPayload {
  providers?: { configured?: boolean; message?: string }
}

/** 干预模式取值 → 作者可读文案（与后端 modeLabel 一套） */
const MODE_LABEL: Record<string, string> = {
  auto: '全自动',
  'semi-auto': '半自动',
  manual: '手动逐步',
}

const MODE_OPTIONS: { value: string; label: string }[] = [
  { value: 'auto', label: '全自动' },
  { value: 'semi-auto', label: '半自动' },
  { value: 'manual', label: '手动逐步' },
]

const GENRES = ['古风悬疑', '玄幻', '武侠', '科幻', '都市', '待定']

/** 设为「当前作品」（client.ts 未导出对应方法，直接用 request 调后端） */
const openProject = (id: string) =>
  request(`/api/projects/${encodeURIComponent(id)}/open`, { method: 'POST' })

/** 书脊色轮换：index % 4 → 无修饰 / is-2 / is-3 / is-4 */
function spineClass(i: number): string {
  return classNames(
    'proj-spine',
    i % 4 === 1 && 'is-2',
    i % 4 === 2 && 'is-3',
    i % 4 === 3 && 'is-4',
  )
}

const errMsg = (e: unknown) => (e instanceof Error ? e.message : '操作失败，请重试。')

/**
 * 后端 `listProjects` 返回的更新时刻形如 `YYYY-MM-DD HH:mm`。
 * 只面向作者展示「月-日 时:分」，不带年份，更清爽。
 */
function fmtClock(s: string): string {
  return s.length >= 16 ? s.slice(5, 16) : s
}

export default function Projects() {
  const navigate = useNavigate()
  const { setCurrent: setCurrentProject } = useProject()

  const [projects, setProjects] = useState<ProjectSummary[]>([])
  const [currentId, setCurrentId] = useState<string | null>(null)
  const [resume, setResume] = useState<Resume | null>(null)
  const [status, setStatus] = useState<'loading' | 'error' | 'ready'>('loading')
  const [error, setError] = useState('')
  const [warn, setWarn] = useState<string | null>(null)

  const [modalOpen, setModalOpen] = useState(false)
  const [fTitle, setFTitle] = useState('')
  const [fGenre, setFGenre] = useState(GENRES[0])
  const [fPremise, setFPremise] = useState('')
  const [fMode, setFMode] = useState('semi-auto')
  const [creating, setCreating] = useState(false)

  /* 作品导出：先取章节清单算出两种范围各有多少章，再按选择取正文 */
  const [exportTarget, setExportTarget] = useState<ProjectSummary | null>(null)
  const [exportScope, setExportScope] = useState<'committed' | 'all'>('committed')
  const [exportRows, setExportRows] = useState<ChapterRow[] | null>(null)
  const [exportBusy, setExportBusy] = useState<'txt' | 'md' | 'truth' | null>(null)

  const load = useCallback(async () => {
    setStatus('loading')
    try {
      const res = (await listProjects()) as { projects: ProjectSummary[]; current: string | null }
      const list = res.projects ?? []
      setProjects(list)
      const cur = res.current ?? list[0]?.id ?? null
      setCurrentId(cur)
      if (cur) setCurrentProject(cur)
      setStatus('ready')
      if (cur) {
        try {
          const ov = (await getOverview(cur)) as { resume: Resume }
          setResume(ov.resume ?? null)
        } catch {
          setResume(null)
        }
      } else {
        setResume(null)
      }
    } catch (e) {
      setError(errMsg(e))
      setStatus('error')
    }
  }, [setCurrentProject])

  useEffect(() => {
    void load()
  }, [load])

  useEffect(() => {
    health()
      .then((h) => {
        const info = h as HealthPayload
        if (info?.providers && info.providers.configured === false) {
          setWarn(info.providers.message || '尚未配置模型密钥，生成类功能暂不可用。')
        }
      })
      .catch(() => {
        /* 健康检查失败不阻塞首页 */
      })
  }, [])

  const open = useCallback(
    async (p: ProjectSummary, forceWorkbench = false) => {
      try {
        await openProject(p.id)
        setCurrentProject(p.id)
        setCurrentId(p.id)
      } catch (e) {
        toast(errMsg(e), 'error')
        return
      }
      const started = p.chaptersDone > 0
      navigate(forceWorkbench || started ? '/workbench' : '/chat')
    },
    [navigate, setCurrentProject],
  )

  const submitCreate = useCallback(async () => {
    const title = fTitle.trim()
    if (!title) {
      toast('先给作品起个名字', 'warn')
      return
    }
    setCreating(true)
    try {
      const res = (await createProject({
        title,
        genre: fGenre,
        premise: fPremise.trim(),
        mode: fMode,
      })) as { project?: { id?: string } }
      const id = res?.project?.id
      if (id) {
        await openProject(id)
        setCurrentProject(id)
      }
      setModalOpen(false)
      setFTitle('')
      setFPremise('')
      await load()
      toast(`已创建《${title}》`, 'ok')
    } catch (e) {
      toast(errMsg(e), 'error')
    } finally {
      setCreating(false)
    }
  }, [fTitle, fGenre, fPremise, fMode, load, setCurrentProject])

  /* ------------------------------------------------------------------ *
   * 作品导出
   * ------------------------------------------------------------------ */

  /** 打开导出弹窗：先取一次章节清单，好把两种范围各有多少章摆在弹窗里 */
  const openExport = useCallback(async (p: ProjectSummary) => {
    setExportTarget(p)
    setExportScope('committed')
    setExportRows(null)
    try {
      const res = (await listChapters(p.id)) as { chapters?: ChapterRow[] }
      setExportRows(res.chapters ?? [])
    } catch (e) {
      setExportRows([])
      toast(errMsg(e), 'error')
    }
  }, [])

  /** 已成稿（done / revise）且有正文的章节 */
  const committedRows = (exportRows ?? []).filter(
    (c) => COMMITTED_STATUSES.includes(c.status) && c.words > 0,
  )
  /** 全部有正文的章节（草稿也算） */
  const writtenRows = (exportRows ?? []).filter((c) => c.words > 0)
  const pickedRows = exportScope === 'committed' ? committedRows : writtenRows

  /**
   * 执行导出：按弹窗里选定的范围逐章取正文，再拼成 TXT / Markdown / 真相文件。
   * 真相文件额外取设定类接口（世界观 / 角色 / 伏笔 / 结构 / 文风），一次并发取齐。
   */
  const runExport = useCallback(
    async (kind: 'txt' | 'md' | 'truth') => {
      const target = exportTarget
      if (!target) return
      const rows = exportScope === 'committed' ? committedRows : writtenRows
      if (!rows.length) {
        toast(
          exportScope === 'committed' ? '还没有已成稿的章节，先定稿再导出' : '这本书还没有正文',
          'warn',
        )
        return
      }
      setExportBusy(kind)
      try {
        const exportedAt = nowStamp()
        const chapters: ExportChapter[] = []
        for (const row of rows) {
          const data = (await getChapter(target.id, row.n)) as {
            chapter?: { title?: string; words?: number; paragraphs?: string[] }
          }
          chapters.push({
            n: row.n,
            title: data.chapter?.title || row.title,
            words: data.chapter?.words ?? row.words,
            text: (data.chapter?.paragraphs ?? []).join('\n\n'),
          })
        }
        const book = {
          title: target.title,
          genre: target.genre,
          logline: target.logline,
          exportedAt,
          chapters,
        }
        const base = safeFilename(target.title)

        if (kind === 'txt') {
          downloadTextFile(`${base}.txt`, buildBookTxt(book))
        } else if (kind === 'md') {
          downloadTextFile(`${base}.md`, buildBookMarkdown(book), 'text/markdown;charset=utf-8')
        } else {
          const [structure, world, chars, hooks, style] = await Promise.all([
            getStructure(target.id),
            getWorld(target.id),
            listCharacters(target.id),
            listHooks(target.id),
            getStyle(target.id),
          ])
          const s = structure as {
            volumes?: TruthBundle['volumes']
            nodes?: TruthBundle['nodes']
            plotlines?: TruthBundle['plotlines']
          }
          const w = world as { rules?: TruthBundle['rules'] }
          const c = chars as { characters?: TruthBundle['characters'] }
          const h = hooks as { hooks?: TruthBundle['hooks'] }
          const st = style as { profile?: TruthBundle['style'] }
          downloadTextFile(
            `${base}真相文件.md`,
            buildTruthMarkdown({
              book,
              chapters: rows,
              volumes: s.volumes ?? [],
              nodes: s.nodes ?? [],
              rules: w.rules ?? [],
              characters: c.characters ?? [],
              hooks: h.hooks ?? [],
              plotlines: s.plotlines ?? [],
              style: st.profile ?? null,
            }),
            'text/markdown;charset=utf-8',
          )
        }
        toast(`已导出《${target.title}》· ${rows.length} 章`, 'ok')
        setExportTarget(null)
      } catch (e) {
        toast(errMsg(e), 'error')
      } finally {
        setExportBusy(null)
      }
    },
    [exportTarget, exportScope, committedRows, writtenRows],
  )

  const totalWords = projects.reduce((s, p) => s + p.words, 0)
  const ongoing = projects.filter((p) => p.chaptersDone > 0).length
  const hooksTotal = projects.reduce((s, p) => s + p.hooksTotal, 0)
  const hooksDone = projects.reduce((s, p) => s + p.hooksResolved, 0)
  const hookRate = hooksTotal ? Math.round((hooksDone / hooksTotal) * 100) : 0
  const totalCost = projects.reduce((s, p) => s + p.budgetUsed, 0)
  const currentProject = projects.find((p) => p.id === currentId) ?? null

  // 「最近更新」：以各项目真实的最后更新时刻排序取前 5 条，作为「最近生成记录」来源。
  // 后端首页接口只返回项目级更新时间（`updatedAt`），不伪造具体生成事件与时刻。
  const recent = [...projects]
    .filter((p) => p.updatedAt)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    .slice(0, 5)

  const sub =
    status === 'ready' ? `${projects.length} 个作品 · 累计 ${fmtInt(totalWords)} 字` : undefined

  return (
    <>
      <TopBar
        title="我的作品"
        sub={sub}
        actions={
          <>
            <Link className="btn btn-ghost btn-sm" to="/disassemble">
              <Icon name="upload" size={16} />
              拆书
            </Link>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => setModalOpen(true)}
            >
              <Icon name="plus" size={16} />
              新建作品
            </button>
          </>
        }
      />

      <div className="stack-24">
        {warn ? (
          <div className="card card-pad">
            <div className="row-between">
              <div className="row">
                <Icon name="alert-triangle" size={16} />
                <span className="fs-13">{warn}</span>
              </div>
              <Link className="btn btn-ghost btn-sm" to="/settings">
                去设置
              </Link>
            </div>
          </div>
        ) : null}

        {status === 'loading' ? (
          <Loading text="正在加载作品…" />
        ) : status === 'error' ? (
          <ErrorState message={error} onRetry={() => void load()} />
        ) : (
          <>
            <div className="grid-4">
            <div className="stat">
              <div className="stat-label">作品数</div>
              <div className="stat-value fs-20">{projects.length}</div>
              <div className="fs-12 muted">{ongoing} 个进行中</div>
            </div>
            <div className="stat">
              <div className="stat-label">累计字数</div>
              <div className="stat-value fs-20">{fmtInt(totalWords)}</div>
              <div className="fs-12 muted">全部作品合计</div>
            </div>
            <div className="stat">
              <div className="stat-label">伏笔回收率</div>
              <div className="stat-value fs-20">{hookRate}%</div>
              <div className="fs-12 muted">
                已回收 {hooksDone} / {hooksTotal} 条
              </div>
            </div>
            <div className="stat">
              <div className="stat-label">累计成本</div>
              <div className="stat-value fs-20">{fmtMoney(totalCost)}</div>
              <div className="fs-12 muted">按接口用量计</div>
            </div>
          </div>

          {currentProject && resume ? (
            <div className="proj-card is-current">
              <div className={spineClass(0)} />
              <div className="proj-body">
                <div className="proj-head">
                  <div>
                    <div className="proj-title">{currentProject.title}</div>
                    <div className="proj-sub">
                      {currentProject.genre} · {MODE_LABEL[currentProject.mode] ?? currentProject.mode}
                    </div>
                  </div>
                  <span className="tag tag-info">当前作品</span>
                </div>
                <div className="proj-logline">
                  {currentProject.logline || '还没有一句话灵感，去共创对话聊聊。'}
                </div>
                <div className="proj-stats">
                  <span>
                    第 {currentProject.chaptersDone} / {currentProject.chaptersTotal} 章
                  </span>
                  <span>{fmtInt(currentProject.words)} 字</span>
                  <span>
                    伏笔 {currentProject.hooksResolved}/{currentProject.hooksTotal}
                  </span>
                  <span>
                    {fmtMoney(currentProject.budgetUsed)} / {fmtMoney(currentProject.budgetTotal)}
                  </span>
                </div>
                <div className="fs-12 muted">
                  {resume.label}：{resume.reason}
                </div>
              </div>
              <div className="proj-foot">
                <span className="fs-12 muted">最后更新 {currentProject.updatedAt}</span>
                <div className="row">
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    onClick={() => void openExport(currentProject)}
                  >
                    导出
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={() => void open(currentProject, true)}
                  >
                    继续
                  </button>
                </div>
              </div>
            </div>
          ) : projects.length === 0 ? (
            <div className="card">
              <div className="card-body">
                <div className="empty">
                  <Icon name="library" size={24} />
                  <div className="fs-16 serif">还没有作品</div>
                  <div className="fs-13">从一个名字和一句话灵感开始</div>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={() => setModalOpen(true)}
                  >
                    新建作品
                  </button>
                </div>
              </div>
            </div>
          ) : null}

          <section className="card">
            <div className="card-head">
              <h2>最近生成记录</h2>
              <span className="tag tag-quiet">按最后更新排序</span>
            </div>
            <div className="card-body" style={{ padding: 0 }}>
              {recent.length === 0 ? (
                <div className="empty">
                  <Icon name="pen-line" size={24} />
                  <div className="fs-14 serif">还没有生成记录</div>
                  <div className="fs-13">写点什么再回来看，这里会记下最近的创作进度。</div>
                </div>
              ) : (
                <div className="list">
                  {recent.map((p) => (
                    <div key={p.id} className="list-row">
                      <span
                        className="mono fs-12 muted"
                        style={{ width: 88, flex: 'none' }}
                        title="最后更新时刻"
                      >
                        {fmtClock(p.updatedAt)}
                      </span>
                      <span className="row-main">
                        <span className="row-title">{p.title}</span>
                        <span className="row-sub">
                          {p.genre} · 第 {p.chaptersDone}/{p.chaptersTotal} 章 · {fmtInt(p.words)} 字
                        </span>
                      </span>
                      {p.chaptersDone > 0 ? (
                        <span className="tag tag-quiet">进行中</span>
                      ) : (
                        <span className="tag tag-quiet">未开始</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <h2>全部作品</h2>
              <span className="tag tag-quiet">{projects.length} 个</span>
            </div>
            <div className="card-body">
              <div className="proj-grid">
                {projects.map((p, i) => {
                  const isCurrent = p.id === currentId
                  const started = p.chaptersDone > 0
                  return (
                    <div key={p.id} className={classNames('proj-card', isCurrent && 'is-current')}>
                      <div className={spineClass(i)} />
                      <div className="proj-body">
                        <div className="proj-head">
                          <div>
                            <div className="proj-title">{p.title}</div>
                            <div className="proj-sub">
                              {p.genre} · {MODE_LABEL[p.mode] ?? p.mode}
                            </div>
                          </div>
                          {isCurrent ? (
                            <span className="tag tag-info">当前</span>
                          ) : started ? null : (
                            <span className="tag tag-quiet">未开始</span>
                          )}
                        </div>
                        <div className="proj-logline">{p.logline || '还没有一句话灵感。'}</div>
                        <div className="proj-stats">
                          <span>
                            第 {p.chaptersDone} / {p.chaptersTotal} 章
                          </span>
                          <span>{fmtInt(p.words)} 字</span>
                          <span>
                            伏笔 {p.hooksResolved}/{p.hooksTotal}
                          </span>
                          <span>
                            {fmtMoney(p.budgetUsed)} / {fmtMoney(p.budgetTotal)}
                          </span>
                          {started ? <span>审计 {p.auditPass}%</span> : null}
                        </div>
                      </div>
                      <div className="proj-foot">
                        <span className="fs-12 muted">{p.updatedAt}</span>
                        <div className="row">
                          <button
                            type="button"
                            className="btn btn-ghost btn-sm"
                            onClick={() => void openExport(p)}
                          >
                            导出
                          </button>
                          <button
                            type="button"
                            className={classNames('btn', 'btn-sm', started ? 'btn-ghost' : 'btn-primary')}
                            onClick={() => void open(p)}
                          >
                            {started ? '打开' : '开始立项'}
                          </button>
                        </div>
                      </div>
                    </div>
                  )
                })}

                <button type="button" className="proj-new" onClick={() => setModalOpen(true)}>
                  <Icon name="plus" size={24} />
                  <strong>新建作品</strong>
                  <span className="fs-12">从一个名字和一句话灵感开始，不填表</span>
                </button>
              </div>
            </div>
          </section>
          </>
        )}
      </div>

      {modalOpen ? (
        <div className="modal">
          <div className="modal-veil" onClick={() => setModalOpen(false)} />
          <div className="modal-card">
            <div className="card-head">
              <h2>新建作品</h2>
              <button type="button" className="btn btn-quiet btn-sm" onClick={() => setModalOpen(false)}>
                关闭
              </button>
            </div>
            <div className="card-body stack">
              <p className="fs-13 muted">
                不用先填设定表。给一个名字和一句话灵感即可，剩下的在「共创对话」里边聊边立。
              </p>
              <div className="field">
                <label className="field-label" htmlFor="np-title">
                  作品名
                </label>
                <input
                  id="np-title"
                  className="input"
                  type="text"
                  placeholder="例如：雁回关"
                  value={fTitle}
                  onChange={(e) => setFTitle(e.target.value)}
                />
              </div>
              <div className="grid-2">
                <div className="field">
                  <label className="field-label" htmlFor="np-genre">
                    题材
                  </label>
                  <select
                    id="np-genre"
                    className="select"
                    value={fGenre}
                    onChange={(e) => setFGenre(e.target.value)}
                  >
                    {GENRES.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <span className="field-label">干预模式</span>
                  <div className="seg">
                    {MODE_OPTIONS.map((m) => (
                      <button
                        key={m.value}
                        type="button"
                        className={m.value === fMode ? 'active' : undefined}
                        onClick={() => setFMode(m.value)}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="field">
                <label className="field-label" htmlFor="np-premise">
                  一句话灵感
                </label>
                <textarea
                  id="np-premise"
                  className="textarea"
                  placeholder="例如：一个北境小吏追查失踪案，发现王朝正在被「文脉」的力量吞噬。"
                  value={fPremise}
                  onChange={(e) => setFPremise(e.target.value)}
                />
                <span className="field-hint">这句话会作为共创对话的开场，第一条追问会围绕它展开。</span>
              </div>
            </div>
            <div className="card-foot row-between">
              <span className="fs-12 muted">{creating ? '创建中…' : ''}</span>
              <div className="row">
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={() => setModalOpen(false)}
                  disabled={creating}
                >
                  取消
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => void submitCreate()}
                  disabled={creating}
                >
                  创建并开始立项
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {exportTarget ? (
        <div className="modal">
          <div className="modal-veil" onClick={() => setExportTarget(null)} />
          <div className="modal-card">
            <div className="card-head">
              <h2>导出《{exportTarget.title}》</h2>
              <button
                type="button"
                className="btn btn-quiet btn-sm"
                onClick={() => setExportTarget(null)}
              >
                关闭
              </button>
            </div>
            <div className="card-body stack">
              <div className="field">
                <span className="field-label">导出范围</span>
                <div className="seg">
                  <button
                    type="button"
                    className={exportScope === 'committed' ? 'active' : undefined}
                    onClick={() => setExportScope('committed')}
                  >
                    仅已成稿（{committedRows.length} 章）
                  </button>
                  <button
                    type="button"
                    className={exportScope === 'all' ? 'active' : undefined}
                    onClick={() => setExportScope('all')}
                  >
                    全部有正文（{writtenRows.length} 章）
                  </button>
                </div>
                <span className="field-hint">
                  {exportRows === null
                    ? '正在读取章节清单…'
                    : exportScope === 'committed'
                      ? '已成稿 = 已定稿或修订中的章节，草稿不会混进来。'
                      : '只要写了正文就导出，包含草稿与待审计章节。'}
                </span>
              </div>

              <div className="stack-8">
                <button
                  type="button"
                  className="btn btn-primary btn-block"
                  disabled={exportBusy !== null || pickedRows.length === 0}
                  onClick={() => void runExport('txt')}
                >
                  {exportBusy === 'txt' ? '正在导出…' : '导出全书 TXT'}
                </button>
                <button
                  type="button"
                  className="btn btn-ghost btn-block"
                  disabled={exportBusy !== null || pickedRows.length === 0}
                  onClick={() => void runExport('md')}
                >
                  {exportBusy === 'md' ? '正在导出…' : '导出全书 Markdown'}
                </button>
                <button
                  type="button"
                  className="btn btn-ghost btn-block"
                  disabled={exportBusy !== null || pickedRows.length === 0}
                  onClick={() => void runExport('truth')}
                >
                  {exportBusy === 'truth' ? '正在导出…' : '导出真相文件（Markdown）'}
                </button>
              </div>

              <p className="fs-12 muted">
                导出的是本机已保存的正文，按「第 N 章 标题」顺序拼接；真相文件另含世界观、角色、
                伏笔、章纲、支线、文风与章节台账，供存档与改稿。
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </>
  )
}
